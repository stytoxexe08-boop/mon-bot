import os
import asyncio
import re
import json
import datetime
from pathlib import Path

import discord
from discord import app_commands

# ─── Intents ─────────────────────────────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

# ─── Constants ───────────────────────────────────────────────────────────────
SWEAR_WORDS = [
    # French
    "putain", "merde", "connard", "salope", "enculé", "pute", "batard",
    "fdp", "tg", "ta gueule", "nique", "ntm", "pd", "grosse", "bouffon",
    "baltringue", "bâtard", "con", "conne", "couille", "bite", "chier",
    "fait chier",
    # English
    "fuck", "shit", "bitch", "asshole", "bastard", "cunt", "dick",
    "faggot", "nigger", "whore", "slut",
    # Spanish
    "puta", "mierda", "coño", "pendejo", "cabron", "joder",
    # Italian
    "cazzo", "vaffanculo", "stronzo", "puttana",
    # German
    "scheiße", "hurensohn", "arschloch", "wichser",
    # Arabic
    "كس", "عرص", "شرموطة",
    # Portuguese
    "porra", "caralho", "filho da puta",
    # Russian
    "блять", "сука", "пиздец", "ебать",
]
HEART_TRIGGERS  = ["lynx-fr", "serveur"]
WELCOME_CHANNEL = "💬｜𝗖hat"
LOGS_CHANNEL    = "📋｜𝗟ogs-𝗚énéral"
SUPERIOR_NAME      = "lynx_yoxsnow"
MODERATOR_ROLE     = "Modérateur"
AUTO_DELETE_DELAY  = 10  # seconds for all channel bot messages

GREETINGS = re.compile(
    r"^(hello|hi|hey|bonjour|salut|hola|ciao|hallo|konnichiwa|merhaba"
    r"|привет|olá|namaste|yo|wsh|wesh|cc|slt)[\s!.,]*$",
    re.IGNORECASE,
)
POSITIVE_REPLIES = re.compile(
    r"(bien|très bien|super|génial|top|nikel|nickel|good|fine|great|perfect"
    r"|bene|gut|wunderbar|excellent|parfait|ça va|ca va|oui|yes|ouais)",
    re.IGNORECASE,
)

ALLOWED_LINK_DOMAINS = [
    "cdn.discordapp.com",
    "media.discordapp.net",
    "tenor.com",
    "giphy.com",
]
INVITE_PATTERN = re.compile(
    r"discord\.gg/\S+|discord\.com/invite/\S+",
    re.IGNORECASE,
)
LINK_PATTERN = re.compile(
    r"https?://\S+|www\.\S+|discord\.gg/\S+"
    r"|\S+\.(com|fr|net|org|io|gg|tv|xyz|co|me"
    r"|info|biz|app|dev|live|to|link|site|online|store|shop|club)\b",
    re.IGNORECASE,
)

# ─── Colors ──────────────────────────────────────────────────────────────────
COLOR_RED    = 0xE74C3C
COLOR_ORANGE = 0xE67E22
COLOR_YELLOW = 0xF1C40F
COLOR_GREEN  = 0x2ECC71
COLOR_BLUE   = 0x3498DB
COLOR_GREY   = 0x95A5A6

# ─── Persistent data ─────────────────────────────────────────────────────────
WARNINGS_FILE = Path(__file__).parent / "warnings.json"
UNBANS_FILE   = Path(__file__).parent / "scheduled_unbans.json"

def _load_json(path: Path) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return {}

def _save_json(path: Path, data: dict):
    path.write_text(json.dumps(data, indent=2))

_warnings: dict[str, int] = _load_json(WARNINGS_FILE)
_scheduled_unbans: dict[str, dict] = _load_json(UNBANS_FILE)  # {user_id: {guild_id, unban_at}}

def get_warning_count(uid: int) -> int:
    return _warnings.get(str(uid), 0)

def set_warning_count(uid: int, count: int):
    _warnings[str(uid)] = count
    _save_json(WARNINGS_FILE, _warnings)

def clear_warnings(uid: int):
    _warnings.pop(str(uid), None)
    _save_json(WARNINGS_FILE, _warnings)

def save_scheduled_unban(user_id: int, guild_id: int, unban_at: datetime.datetime):
    _scheduled_unbans[str(user_id)] = {
        "guild_id": guild_id,
        "unban_at": unban_at.isoformat(),
    }
    _save_json(UNBANS_FILE, _scheduled_unbans)

def remove_scheduled_unban(user_id: int):
    _scheduled_unbans.pop(str(user_id), None)
    _save_json(UNBANS_FILE, _scheduled_unbans)

# ─── In-memory state ─────────────────────────────────────────────────────────
active_greetings: dict[int, int] = {}   # user_id -> channel_id
_unban_tasks: dict[int, asyncio.Task] = {}  # user_id -> Task
_first_message_users: set[int] = set()  # user_ids who already sent their first message

# ─── Log helpers ──────────────────────────────────────────────────────────────

def _log_embed(title: str, color: int,
               user: discord.User | discord.Member | None = None) -> discord.Embed:
    embed = discord.Embed(title=title, color=color, timestamp=discord.utils.utcnow())
    if user:
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_author(
            name=f"{user.display_name}  •  @{user.name}",
            icon_url=user.display_avatar.url,
        )
    return embed

async def send_log(guild: discord.Guild, embed: discord.Embed):
    ch = get_log_channel(guild)
    if ch:
        try:
            await ch.send(embed=embed)
        except discord.Forbidden:
            pass


async def log_command(interaction: discord.Interaction, **params):
    """Log every slash command use to the logs channel."""
    if not interaction.guild:
        return
    cmd = interaction.command.name if interaction.command else "?"
    embed = discord.Embed(
        title=f"⌨️ Commande utilisée : `/{cmd}`",
        color=0x5865F2,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_author(
        name=f"{interaction.user.display_name}  •  @{interaction.user.name}",
        icon_url=interaction.user.display_avatar.url,
    )
    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.add_field(name="Utilisateur", value=interaction.user.mention, inline=True)
    ch = interaction.channel
    embed.add_field(name="Salon", value=ch.mention if ch else "—", inline=True)
    if params:
        embed.add_field(
            name="Paramètres",
            value="\n".join(f"**{k}:** {v}" for k, v in params.items()),
            inline=False,
        )
    await send_log(interaction.guild, embed)


# ─── Helpers ─────────────────────────────────────────────────────────────────

def is_superior(member: discord.Member) -> bool:
    return member.name.lower() == SUPERIOR_NAME.lower()

def is_privileged(member: discord.Member) -> bool:
    return is_superior(member) or member.guild_permissions.administrator

def is_exempt(member: discord.Member) -> bool:
    return is_superior(member) or member.guild_permissions.administrator

def _hierarchy_ok(issuer: discord.Member, target: discord.Member) -> bool:
    """True if issuer outranks target in role hierarchy, or issuer is the superior."""
    if issuer.name == SUPERIOR_NAME:
        return True
    return issuer.top_role.position > target.top_role.position

def contains_swear(text: str) -> bool:
    for word in SWEAR_WORDS:
        if re.search(r'\b' + re.escape(word) + r'\b', text, re.IGNORECASE):
            return True
    return False

def contains_heart_trigger(text: str) -> bool:
    return any(t in text.lower() for t in HEART_TRIGGERS)

def extract_blocked_link(text: str) -> str | None:
    for match in LINK_PATTERN.finditer(text):
        url = match.group(0)
        if any(d in url.lower() for d in ALLOWED_LINK_DOMAINS):
            continue
        return url
    return None

def get_log_channel(guild: discord.Guild) -> discord.TextChannel | None:
    for ch in guild.text_channels:
        if ch.name == LOGS_CHANNEL:
            return ch
        if "logs" in ch.name.lower() and "général" in ch.name.lower():
            return ch
    return None

def find_member_by_name(guild: discord.Guild, name: str) -> discord.Member | None:
    n = name.lower().lstrip("@")
    for m in guild.members:
        if m.name.lower() == n or m.display_name.lower() == n:
            return m
    return None

def parse_duration(s: str) -> datetime.timedelta | None:
    """Parse '1d', '7d', '24h', '30m' into a timedelta. Returns None on failure."""
    match = re.fullmatch(r"(\d+)(d|h|m)", s.strip(), re.IGNORECASE)
    if not match:
        return None
    val, unit = int(match.group(1)), match.group(2).lower()
    if unit == "d":
        return datetime.timedelta(days=val)
    if unit == "h":
        return datetime.timedelta(hours=val)
    if unit == "m":
        return datetime.timedelta(minutes=val)
    return None

async def send_temp(channel: discord.abc.Messageable, embed: discord.Embed,
                    delay: int = AUTO_DELETE_DELAY, content: str = ""):
    try:
        msg = await channel.send(content=content, embed=embed)
        await asyncio.sleep(delay)
        await msg.delete()
    except (discord.Forbidden, discord.NotFound):
        pass

async def try_dm(user: discord.User | discord.Member, embed: discord.Embed) -> bool:
    try:
        await user.send(embed=embed)
        return True
    except (discord.Forbidden, discord.HTTPException):
        return False

# ─── Scheduled unban ─────────────────────────────────────────────────────────

async def _do_unban_after(user_id: int, guild_id: int, delay_seconds: float):
    await asyncio.sleep(delay_seconds)
    guild = client.get_guild(guild_id)
    if guild:
        try:
            user = await client.fetch_user(user_id)
            await guild.unban(user, reason="Durée du ban expirée")
            e = _log_embed("🔓 Ban temporaire expiré", COLOR_GREEN, user)
            e.add_field(name="Utilisateur", value=f"{user.mention if hasattr(user, 'mention') else user} — `@{user.name}`", inline=True)
            e.add_field(name="ID", value=f"`{user.id}`", inline=True)
            e.add_field(name="Action", value="Débanni automatiquement à l'expiration du ban temporaire.", inline=False)
            await send_log(guild, e)
        except Exception as e:
            print(f"Auto-unban failed for {user_id}: {e}")
    remove_scheduled_unban(user_id)
    _unban_tasks.pop(user_id, None)

def schedule_unban(user_id: int, guild_id: int, unban_at: datetime.datetime):
    delay = max(0.0, (unban_at - discord.utils.utcnow()).total_seconds())
    save_scheduled_unban(user_id, guild_id, unban_at)
    task = asyncio.create_task(_do_unban_after(user_id, guild_id, delay))
    _unban_tasks[user_id] = task

# ─── Warning system ──────────────────────────────────────────────────────────

async def apply_warning(member: discord.Member, channel: discord.TextChannel):
    uid = member.id
    count = get_warning_count(uid) + 1
    set_warning_count(uid, count)

    e = _log_embed("⚠️ Avertissement émis", COLOR_YELLOW, member)
    e.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
    e.add_field(name="Total avertissements", value=f"**{count}**", inline=True)
    await send_log(member.guild, e)

    async def do_timeout(minutes: int, reason: str):
        until = discord.utils.utcnow() + datetime.timedelta(minutes=minutes)
        try:
            await member.timeout(until, reason=reason)
            e2 = _log_embed("🔇 Mise en sourdine automatique", COLOR_RED, member)
            e2.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
            e2.add_field(name="Durée", value=f"**{minutes} minute(s)**", inline=True)
            e2.add_field(name="Raison", value=reason, inline=False)
            await send_log(member.guild, e2)
        except (discord.Forbidden, discord.HTTPException) as e:
            print(f"Timeout failed for {member}: {e}")

    if count == 2:
        dm = discord.Embed(
            title="🚫 Avertissement #2 — Mise en sourdine",
            description="Tu as utilisé un langage inapproprié à deux reprises. "
                        "Tu es **mis en sourdine pendant 1 minute**.\n"
                        "Merci de respecter les règles.",
            color=COLOR_ORANGE, timestamp=discord.utils.utcnow(),
        )
        dm.set_footer(text="Prochain manquement = sanctions plus sévères")
        await try_dm(member, dm)
        await do_timeout(1, "Avertissement #2")

    elif count == 5:
        dm = discord.Embed(
            title="⛔ Avertissement #5 — Mise en sourdine",
            description="Cinq avertissements. Tu es **mis en sourdine pendant 4 minutes**.\n"
                        "Continue ainsi et les sanctions seront permanentes.",
            color=COLOR_ORANGE, timestamp=discord.utils.utcnow(),
        )
        dm.set_footer(text="Dernier avertissement avant sanction grave")
        await try_dm(member, dm)
        await do_timeout(4, "Avertissement #5")

    elif count == 8:
        dm = discord.Embed(
            title="🔴 Avertissement #8 — Mise en sourdine sévère",
            description="**8 avertissements.** Tu es **mis en sourdine pendant 30 minutes** "
                        "et la modération a été notifiée.\n"
                        "La prochaine infraction peut entraîner un bannissement.",
            color=COLOR_RED, timestamp=discord.utils.utcnow(),
        )
        dm.set_footer(text="La modération a été alertée")
        await try_dm(member, dm)
        await do_timeout(30, "Avertissement #8")

        # Ping the moderator in the LOGS channel only
        moderator = discord.utils.get(member.guild.members, name=SUPERIOR_NAME)
        mod_mention = moderator.mention if moderator else f"@{SUPERIOR_NAME}"
        log_ch = get_log_channel(member.guild)
        if log_ch:
            alert = discord.Embed(
                title="🚨 Alerte modération",
                description=f"{member.mention} a atteint **8 avertissements** — sourdine 30 min.",
                color=COLOR_RED, timestamp=discord.utils.utcnow(),
            )
            try:
                await log_ch.send(content=mod_mention, embed=alert)
            except discord.Forbidden:
                pass

    elif count >= 9:
        dm = discord.Embed(
            title="⚠️ Avertissement supplémentaire",
            description=f"Tu cumules **{count} avertissements**. "
                        "Ton comportement est surveillé de près.",
            color=COLOR_RED, timestamp=discord.utils.utcnow(),
        )
        await try_dm(member, dm)
        e3 = _log_embed("📨 DM envoyé — Avertissement récidive", COLOR_BLUE, member)
        e3.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
        e3.add_field(name="Avertissements", value=f"**{count}**", inline=True)
        e3.add_field(name="Action", value="DM d'avertissement envoyé au membre.", inline=False)
        await send_log(member.guild, e3)
        # Every 2 warnings after 8 (10, 12, 14 …): 1-hour timeout, no ping
        if count % 2 == 0:
            await do_timeout(60, f"Avertissement #{count} — récidive")

# ─── Greeting handler ─────────────────────────────────────────────────────────

async def handle_greeting(message: discord.Message):
    uid = message.author.id
    channel = message.channel
    active_greetings[uid] = channel.id

    await send_temp(channel, discord.Embed(
        description="Bonjour ! Comment vas-tu aujourd'hui ? 😊",
        color=COLOR_BLUE,
    ))

    def check(m: discord.Message) -> bool:
        return m.author.id == uid and m.channel.id == channel.id and not m.author.bot

    try:
        reply = await client.wait_for("message", timeout=60.0, check=check)
        if POSITIVE_REPLIES.search(reply.content):
            await send_temp(channel, discord.Embed(
                description="Oui merci, et toi ? 😊",
                color=COLOR_BLUE,
            ))
    except asyncio.TimeoutError:
        pass
    finally:
        active_greetings.pop(uid, None)

# ─── Events ──────────────────────────────────────────────────────────────────

@client.event
async def on_ready():
    await tree.sync()
    # Reschedule any pending unbans that survived a restart
    now = discord.utils.utcnow()
    for uid_str, data in list(_scheduled_unbans.items()):
        uid = int(uid_str)
        guild_id = data["guild_id"]
        unban_at = datetime.datetime.fromisoformat(data["unban_at"])
        if unban_at <= now:
            # Already expired — unban immediately
            asyncio.create_task(_do_unban_after(uid, guild_id, 0))
        else:
            delay = (unban_at - now).total_seconds()
            task = asyncio.create_task(_do_unban_after(uid, guild_id, delay))
            _unban_tasks[uid] = task
    print(f"Logged in as {client.user} (ID: {client.user.id})")
    print("mon-bot is connected and running.")


@client.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    content = message.content.strip()
    member = message.author if isinstance(message.author, discord.Member) else None

    # Greeting reply tracking — user is mid-conversation, let it pass through normally
    if member and member.id in active_greetings:
        # Don't re-trigger greeting, still apply filters below
        pass
    elif member and not is_exempt(member) and GREETINGS.match(content):
        # Only start greeting if not already in one
        asyncio.create_task(handle_greeting(message))
        return

    # Exempt users: superior + admins
    if member and is_exempt(member):
        if contains_heart_trigger(content):
            try:
                await message.add_reaction("❤️")
            except (discord.Forbidden, discord.NotFound):
                pass
        return

    # ── Discord invite filter (1-hour timeout) ────────────────────────────────
    invite_m = INVITE_PATTERN.search(content)
    if invite_m:
        invite_link = invite_m.group(0)
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass
        if member:
            until = discord.utils.utcnow() + datetime.timedelta(hours=2)
            try:
                await member.timeout(until, reason="Lien d'invitation Discord")
            except (discord.Forbidden, discord.HTTPException) as e:
                print(f"Invite timeout failed for {member}: {e}")
            einv = _log_embed("🔗 Invitation Discord bloquée", COLOR_RED, member)
            einv.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
            einv.add_field(name="Salon", value=message.channel.mention, inline=True)
            einv.add_field(name="Lien détecté", value=f"`{invite_link[:200]}`", inline=False)
            einv.add_field(name="Sanction", value="Message supprimé + mise en sourdine **2 heures**", inline=False)
            await send_log(member.guild, einv)
        await send_temp(message.channel, discord.Embed(
            title="🚫 Invitation non autorisée",
            description=f"{message.author.mention} — les invitations vers d'autres serveurs "
                        "sont **interdites**. Tu es mis en sourdine **2 heures**.",
            color=COLOR_RED,
        ))
        return

    # ── Swear word filter ─────────────────────────────────────────────────────
    if contains_swear(content):
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass
        if member:
            esw = _log_embed("🗑️ Message supprimé — Langage interdit", COLOR_RED, member)
            esw.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
            esw.add_field(name="Salon", value=message.channel.mention, inline=True)
            esw.add_field(name="Contenu supprimé", value=f"`{content[:300]}`", inline=False)
            esw.add_field(name="Action", value="Message supprimé + avertissement ajouté.", inline=False)
            await send_log(member.guild, esw)
            await apply_warning(member, message.channel)
        await send_temp(message.channel, discord.Embed(
            description=f"⚠️ {message.author.mention} — ce type de langage n'est pas autorisé ici.",
            color=COLOR_YELLOW,
        ))
        return

    # ── Link filter ───────────────────────────────────────────────────────────
    blocked = extract_blocked_link(content)
    if blocked:
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass
        if member:
            until = discord.utils.utcnow() + datetime.timedelta(hours=2)
            try:
                await member.timeout(until, reason="Lien non autorisé")
            except (discord.Forbidden, discord.HTTPException) as e:
                print(f"Link timeout failed for {member}: {e}")
            elk = _log_embed("🔗 Lien non autorisé bloqué", COLOR_RED, member)
            elk.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
            elk.add_field(name="Salon", value=message.channel.mention, inline=True)
            elk.add_field(name="Lien détecté", value=f"`{blocked[:200]}`", inline=False)
            elk.add_field(name="Sanction", value="Message supprimé + mise en sourdine **2 heures**", inline=False)
            await send_log(member.guild, elk)
        await send_temp(message.channel, discord.Embed(
            title="🚫 Lien non autorisé",
            description=f"{message.author.mention} — l'envoi de liens est **interdit**.",
            color=COLOR_RED,
        ))
        return

    # ── Heart reaction ────────────────────────────────────────────────────────
    if contains_heart_trigger(content):
        try:
            await message.add_reaction("❤️")
        except (discord.Forbidden, discord.NotFound):
            pass


@client.event
async def on_member_join(member: discord.Member):
    ej = _log_embed("👋 Nouveau membre arrivé", COLOR_GREEN, member)
    ej.add_field(name="Membre", value=f"{member.mention} — `@{member.name}`", inline=True)
    ej.add_field(name="ID", value=f"`{member.id}`", inline=True)
    ej.add_field(name="Compte créé le", value=f"<t:{int(member.created_at.timestamp())}:D>", inline=True)
    ej.add_field(name="Action", value="Le membre a rejoint le serveur.", inline=False)
    await send_log(member.guild, ej)

    channel = discord.utils.get(member.guild.text_channels, name=WELCOME_CHANNEL)
    if channel is None:
        for ch in member.guild.text_channels:
            if "chat" in ch.name.lower():
                channel = ch
                break

    if channel:
        embed = discord.Embed(
            title="✨ Bienvenue sur le serveur !",
            description=(
                f"Hey {member.mention}, on est **vraiment** content de t'avoir parmi nous ! 🎉\n\n"
                "📖 Pense à consulter les règles avant de te lancer.\n"
                "💬 N'hésite pas à te présenter et profiter de la communauté !\n\n"
                "*On espère que tu te sentiras chez toi ici. 🏠*"
            ),
            color=0x9B59B6,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text="Message supprimé dans 35 secondes")
        await send_temp(channel, embed, delay=35)


@client.event
async def on_member_ban(guild: discord.Guild, user: discord.User):
    dm = discord.Embed(
        title="🔨 Vous avez été banni",
        description=f"Votre compte a été **banni du serveur {guild.name}**.\n"
                    "Contactez la modération si vous pensez à une erreur.",
        color=COLOR_RED, timestamp=discord.utils.utcnow(),
    )
    dm.set_footer(text=guild.name)
    sent = await try_dm(user, dm)
    eb = _log_embed("🔨 Membre banni du serveur", COLOR_RED, user)
    eb.add_field(name="Utilisateur", value=f"`@{user.name}`", inline=True)
    eb.add_field(name="ID", value=f"`{user.id}`", inline=True)
    eb.add_field(name="DM de notification", value="✅ Reçu" if sent else "❌ DMs fermés", inline=True)
    await send_log(guild, eb)


@client.event
async def on_member_remove(member: discord.Member):
    roles = [r.name for r in member.roles if r.name != "@everyone"]
    role_str = ", ".join(roles) if roles else "Aucun"
    el = _log_embed("🚪 Membre a quitté le serveur", COLOR_ORANGE, member)
    el.add_field(name="Membre", value=f"`@{member.name}`", inline=True)
    el.add_field(name="ID", value=f"`{member.id}`", inline=True)
    el.add_field(name="Compte créé le", value=f"<t:{int(member.created_at.timestamp())}:D>", inline=True)
    el.add_field(name="Rôles", value=role_str, inline=False)
    await send_log(member.guild, el)


# ─── Slash commands ───────────────────────────────────────────────────────────

@tree.command(name="avertissements", description="Voir les avertissements d'un utilisateur")
@app_commands.describe(utilisateur="L'utilisateur à vérifier")
async def avertissements(interaction: discord.Interaction, utilisateur: discord.Member):
    await log_command(interaction, utilisateur=str(utilisateur))
    count = get_warning_count(utilisateur.id)
    if count == 0:
        color, status = COLOR_GREEN, "✅ Aucun avertissement"
    elif count < 5:
        color, status = COLOR_YELLOW, f"⚠️ {count} avertissement{'s' if count > 1 else ''}"
    elif count < 8:
        color, status = COLOR_ORANGE, f"🔶 {count} avertissements"
    else:
        color, status = COLOR_RED, f"🔴 {count} avertissements"

    embed = discord.Embed(title="📋 Avertissements", color=color, timestamp=discord.utils.utcnow())
    embed.set_thumbnail(url=utilisateur.display_avatar.url)
    embed.add_field(name="Utilisateur", value=utilisateur.mention, inline=True)
    embed.add_field(name="Statut", value=status, inline=True)
    embed.set_footer(text=f"Demandé par {interaction.user}")
    await interaction.response.send_message(embed=embed)


@tree.command(name="sanctions", description="Voir l'échelle complète des sanctions")
async def sanctions(interaction: discord.Interaction):
    await log_command(interaction)
    embed = discord.Embed(
        title="⚖️ Échelle des sanctions",
        description="Sanctions appliquées selon le nombre d'avertissements :",
        color=COLOR_BLUE, timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="⚠️ 1 avert.", value="Message supprimé, avertissement enregistré.", inline=False)
    embed.add_field(name="🔶 2 avert.", value="DM + sourdine **1 minute**.", inline=False)
    embed.add_field(name="🔶 5 avert.", value="DM + sourdine **4 minutes**.", inline=False)
    embed.add_field(name="🔴 8 avert.", value=f"DM + sourdine **30 minutes** + alerte @{SUPERIOR_NAME}.", inline=False)
    embed.add_field(name="🚨 9+ avert.", value="DM uniquement — modération informée.", inline=False)
    embed.set_footer(text="Admins et supérieur exempts de toutes sanctions.")
    await interaction.response.send_message(embed=embed)


@tree.command(name="demute", description="Retirer la mise en sourdine d'un membre")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(utilisateur="Le membre à démuter")
async def slash_demute(interaction: discord.Interaction, utilisateur: discord.Member):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur))
    try:
        await utilisateur.timeout(None, reason=f"Démute via /demute par {interaction.user}")
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    await try_dm(utilisateur, discord.Embed(
        title="✅ Mise en sourdine levée",
        description="Ta mise en sourdine a été retirée par un administrateur.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    ed = _log_embed("🔊 Mise en sourdine levée", COLOR_GREEN, utilisateur)
    ed.add_field(name="Membre", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    ed.add_field(name="Modérateur", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    ed.add_field(name="Action", value="La mise en sourdine a été retirée manuellement.", inline=False)
    await send_log(interaction.guild, ed)
    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Sourdine retirée",
        description=f"La mise en sourdine de {utilisateur.mention} a été levée.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))


@tree.command(name="retrait", description="Retirer tous les avertissements d'un membre")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(utilisateur="Le membre dont retirer les avertissements")
async def slash_retrait(interaction: discord.Interaction, utilisateur: discord.Member):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur))
    clear_warnings(utilisateur.id)
    try:
        await utilisateur.timeout(None, reason=f"Retrait via /retrait par {interaction.user}")
    except (discord.Forbidden, discord.HTTPException):
        pass
    await try_dm(utilisateur, discord.Embed(
        title="✅ Avertissements retirés",
        description="Tous tes avertissements ont été retirés par un administrateur.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    er = _log_embed("🧹 Sanctions retirées", COLOR_GREEN, utilisateur)
    er.add_field(name="Membre", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    er.add_field(name="Modérateur", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    er.add_field(name="Action", value="Tous les avertissements remis à zéro + sourdine retirée.", inline=False)
    await send_log(interaction.guild, er)
    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Avertissements retirés",
        description=f"Tous les avertissements de {utilisateur.mention} ont été remis à zéro.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))


@tree.command(name="ban", description="Bannir un membre du serveur")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(utilisateur="Le membre à bannir", raison="Raison du ban")
async def slash_ban(interaction: discord.Interaction, utilisateur: discord.Member, raison: str):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur), raison=raison)
    if not is_superior(member):
        if utilisateur.id == interaction.user.id:
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas te bannir toi-même.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

        if utilisateur.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas bannir un **Administrateur**.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

        if not _hierarchy_ok(member, utilisateur):
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas appliquer cette sanction à quelqu'un de ton niveau ou supérieur.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

    # DM before ban
    await try_dm(utilisateur, discord.Embed(
        title="🔨 Vous avez été banni",
        description=f"Vous avez été **banni du serveur {interaction.guild.name}**.\n"
                    f"**Raison :** {raison}",
        color=COLOR_RED, timestamp=discord.utils.utcnow(),
    ))

    try:
        await utilisateur.ban(reason=raison)
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible de bannir : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Membre banni",
        description=f"{utilisateur.mention} a été banni.\n**Raison :** {raison}",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    eban = _log_embed("🔨 Bannissement", COLOR_RED, utilisateur)
    eban.add_field(name="Membre banni", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    eban.add_field(name="ID", value=f"`{utilisateur.id}`", inline=True)
    eban.add_field(name="Modérateur", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    eban.add_field(name="Raison", value=raison, inline=False)
    await send_log(interaction.guild, eban)


@tree.command(name="unban", description="Débannir un utilisateur par son ID Discord")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(user_id="L'ID Discord de l'utilisateur à débannir")
async def slash_unban(interaction: discord.Interaction, user_id: str):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, user_id=user_id)
    try:
        uid = int(user_id.strip())
    except ValueError:
        await interaction.response.send_message(embed=discord.Embed(
            description="❌ ID invalide. Entrez un ID Discord numérique.", color=COLOR_RED,
        ), ephemeral=True)
        return

    try:
        user = await client.fetch_user(uid)
        await interaction.guild.unban(user, reason=f"Débanni par {interaction.user}")
    except discord.NotFound:
        await interaction.response.send_message(embed=discord.Embed(
            description="❌ Utilisateur introuvable ou pas banni.", color=COLOR_RED,
        ), ephemeral=True)
        return
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    # Cancel any pending auto-unban task
    if uid in _unban_tasks:
        _unban_tasks[uid].cancel()
        _unban_tasks.pop(uid, None)
    remove_scheduled_unban(uid)

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Utilisateur débanni",
        description=f"**{user}** (ID: `{uid}`) a été débanni.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    eub = _log_embed("🔓 Débannissement", COLOR_GREEN, user)
    eub.add_field(name="Utilisateur", value=f"`@{user.name}`", inline=True)
    eub.add_field(name="ID", value=f"`{uid}`", inline=True)
    eub.add_field(name="Modérateur", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    eub.add_field(name="Action", value="L'utilisateur a été débanni manuellement.", inline=False)
    await send_log(interaction.guild, eub)


@tree.command(name="permban", description="Bannir un membre pour une durée définie")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(
    utilisateur="Le membre à bannir",
    duree="Durée : ex. 1d, 7d, 30d, 24h",
    raison="Raison du ban",
)
async def slash_permban(interaction: discord.Interaction,
                        utilisateur: discord.Member, duree: str, raison: str):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur), durée=duree, raison=raison)
    if not is_superior(member):
        if utilisateur.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas bannir un **Administrateur**.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

        if not _hierarchy_ok(member, utilisateur):
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas appliquer cette sanction à quelqu'un de ton niveau ou supérieur.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

    delta = parse_duration(duree)
    if delta is None:
        await interaction.response.send_message(embed=discord.Embed(
            description="❌ Format de durée invalide. Exemples : `1d`, `7d`, `24h`, `30m`",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    unban_at = discord.utils.utcnow() + delta

    # DM before ban
    await try_dm(utilisateur, discord.Embed(
        title="🔨 Vous avez été banni temporairement",
        description=f"Vous avez été **banni du serveur {interaction.guild.name}** pour **{duree}**.\n"
                    f"**Raison :** {raison}\n"
                    f"**Fin du ban :** <t:{int(unban_at.timestamp())}:F>",
        color=COLOR_RED, timestamp=discord.utils.utcnow(),
    ))

    try:
        await utilisateur.ban(reason=f"[{duree}] {raison}")
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible de bannir : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    schedule_unban(utilisateur.id, interaction.guild.id, unban_at)

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Ban temporaire appliqué",
        description=f"{utilisateur.mention} banni pour **{duree}**.\n"
                    f"**Raison :** {raison}\n"
                    f"**Débanni automatiquement :** <t:{int(unban_at.timestamp())}:F>",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    epb = _log_embed("🔨 Ban temporaire", COLOR_RED, utilisateur)
    epb.add_field(name="Membre", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    epb.add_field(name="ID", value=f"`{utilisateur.id}`", inline=True)
    epb.add_field(name="Modérateur", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    epb.add_field(name="Durée", value=f"**{duree}**", inline=True)
    epb.add_field(name="Fin du ban", value=f"<t:{int(unban_at.timestamp())}:F>", inline=True)
    epb.add_field(name="Raison", value=raison, inline=False)
    await send_log(interaction.guild, epb)


@tree.command(name="mute", description="Mettre un membre en sourdine")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(
    utilisateur="Le membre à mettre en sourdine",
    duree="Durée en minutes",
    raison="Raison de la mise en sourdine",
)
async def slash_mute(interaction: discord.Interaction,
                     utilisateur: discord.Member, duree: int, raison: str):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur), durée=f"{duree} min", raison=raison)
    if not is_superior(member):
        if utilisateur.id == interaction.user.id:
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas te mettre en sourdine toi-même.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

        if utilisateur.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas mettre en sourdine un **Administrateur**.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

        if not _hierarchy_ok(member, utilisateur):
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas appliquer cette sanction à quelqu'un de ton niveau ou supérieur.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

    until = discord.utils.utcnow() + datetime.timedelta(minutes=duree)
    try:
        await utilisateur.timeout(until, reason=f"/mute par {interaction.user} — {raison}")
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible d'appliquer la sourdine : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    await try_dm(utilisateur, discord.Embed(
        title="🔇 Mise en sourdine",
        description=f"Tu as été **mis en sourdine** sur **{interaction.guild.name}**.\n"
                    f"**Durée :** {duree} minute(s)\n"
                    f"**Raison :** {raison}",
        color=COLOR_ORANGE, timestamp=discord.utils.utcnow(),
    ))

    emu = _log_embed("🔇 Mise en sourdine manuelle", COLOR_ORANGE, utilisateur)
    emu.add_field(name="Membre", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    emu.add_field(name="ID", value=f"`{utilisateur.id}`", inline=True)
    emu.add_field(name="Modérateur", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    emu.add_field(name="Durée", value=f"**{duree} minute(s)**", inline=True)
    emu.add_field(name="Raison", value=raison, inline=False)
    await send_log(interaction.guild, emu)

    await interaction.response.send_message(embed=discord.Embed(
        title="🔇 Sourdine appliquée",
        description=f"{utilisateur.mention} est mis en sourdine pour **{duree} minute(s)**.\n"
                    f"**Raison :** {raison}",
        color=COLOR_ORANGE, timestamp=discord.utils.utcnow(),
    ))
    await asyncio.sleep(AUTO_DELETE_DELAY)
    try:
        msg = await interaction.original_response()
        await msg.delete()
    except (discord.NotFound, discord.HTTPException):
        pass


@tree.command(name="role", description="Afficher tous les rôles du serveur")
async def slash_role(interaction: discord.Interaction):
    await log_command(interaction)
    guild = interaction.guild
    roles = sorted(
        [r for r in guild.roles if r.name != "@everyone"],
        key=lambda r: r.position,
        reverse=True,
    )
    role_list = "\n".join(r.name for r in roles) or "Aucun rôle trouvé."
    embed = discord.Embed(
        title=f"📋 Rôles de {guild.name}",
        description=role_list,
        color=COLOR_BLUE, timestamp=discord.utils.utcnow(),
    )
    embed.set_footer(text=f"{len(roles)} rôle(s) au total")
    await interaction.response.send_message(embed=embed)
    await asyncio.sleep(AUTO_DELETE_DELAY)
    try:
        msg = await interaction.original_response()
        await msg.delete()
    except (discord.NotFound, discord.HTTPException):
        pass


@tree.command(name="avert", description="Émettre un avertissement officiel à un membre")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(utilisateur="Le membre à avertir", raison="Raison de l'avertissement")
async def slash_avert(interaction: discord.Interaction,
                      utilisateur: discord.Member, raison: str):
    issuer = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not issuer:
        return

    await log_command(interaction, utilisateur=str(utilisateur), raison=raison)
    has_mod_role = any(r.name == MODERATOR_ROLE for r in issuer.roles)
    if not (issuer.guild_permissions.administrator or has_mod_role
            or issuer.name == SUPERIOR_NAME):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    if not is_superior(issuer):
        if utilisateur.guild_permissions.administrator or utilisateur.name == SUPERIOR_NAME:
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas avertir un **Administrateur** ou le supérieur.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

        if not _hierarchy_ok(issuer, utilisateur):
            await interaction.response.send_message(embed=discord.Embed(
                title="🚫 Action impossible",
                description="Tu ne peux pas appliquer cette sanction à quelqu'un de ton niveau ou supérieur.",
                color=COLOR_RED,
            ), ephemeral=True)
            return

    await try_dm(utilisateur, discord.Embed(
        title="⚠️ Avertissement Officiel",
        description=(
            f"Tu as reçu un avertissement de la modération pour la raison suivante : **{raison}**.\n"
            "Ceci est un avertissement formel, merci de respecter les règles du serveur."
        ),
        color=COLOR_YELLOW, timestamp=discord.utils.utcnow(),
    ))

    eav = _log_embed("⚠️ Avertissement officiel", COLOR_YELLOW, utilisateur)
    eav.add_field(name="Membre averti", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    eav.add_field(name="ID", value=f"`{utilisateur.id}`", inline=True)
    eav.add_field(name="Modérateur", value=f"{issuer.mention} — `@{issuer.name}`", inline=True)
    eav.add_field(name="Raison", value=raison, inline=False)
    eav.add_field(name="Note", value="Avertissement formel — n'affecte pas le compteur de sanctions automatiques.", inline=False)
    await send_log(interaction.guild, eav)

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Avertissement émis",
        description=f"{utilisateur.mention} a reçu un avertissement officiel.\n**Raison :** {raison}",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    await asyncio.sleep(AUTO_DELETE_DELAY)
    try:
        msg = await interaction.original_response()
        await msg.delete()
    except (discord.NotFound, discord.HTTPException):
        pass


@tree.command(name="mess", description="Envoyer un message embed dans un salon")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(salon="Le salon de destination", contenu="Le contenu du message")
async def slash_mess(interaction: discord.Interaction,
                     salon: discord.TextChannel, contenu: str):
    member = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not member or not is_privileged(member):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Tu n'as pas la permission d'utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, salon=str(salon), contenu=contenu)
    try:
        await salon.send(embed=discord.Embed(
            description=contenu,
            color=COLOR_BLUE,
            timestamp=discord.utils.utcnow(),
        ))
    except discord.Forbidden:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Je n'ai pas la permission d'envoyer dans {salon.mention}.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Message envoyé",
        description=f"Le message a été envoyé dans {salon.mention}.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    await asyncio.sleep(AUTO_DELETE_DELAY)
    try:
        msg = await interaction.original_response()
        await msg.delete()
    except (discord.NotFound, discord.HTTPException):
        pass


@tree.command(name="roleadd", description="Assigner un rôle à un membre (lynx_yoxsnow uniquement)")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(
    utilisateur="Le membre à qui assigner le rôle",
    role="Le rôle à assigner",
)
async def slash_roleadd(interaction: discord.Interaction,
                        utilisateur: discord.Member, role: discord.Role):
    issuer = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not issuer or not is_superior(issuer):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Seul le supérieur peut utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur), role=str(role))
    try:
        await utilisateur.add_roles(role, reason=f"/roleadd par {interaction.user}")
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible d'assigner le rôle : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    erl = _log_embed("✨ Rôle assigné", COLOR_GREEN, utilisateur)
    erl.add_field(name="Membre", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    erl.add_field(name="Rôle", value=role.mention, inline=True)
    erl.add_field(name="Assigné par", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    await send_log(interaction.guild, erl)

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Rôle assigné",
        description=f"{role.mention} a été donné à {utilisateur.mention}.",
        color=COLOR_GREEN, timestamp=discord.utils.utcnow(),
    ))
    await asyncio.sleep(AUTO_DELETE_DELAY)
    try:
        msg = await interaction.original_response()
        await msg.delete()
    except (discord.NotFound, discord.HTTPException):
        pass


@tree.command(name="rolesub", description="Retirer un rôle d'un membre (lynx_yoxsnow uniquement)")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(
    utilisateur="Le membre à qui retirer le rôle",
    role="Le rôle à retirer",
)
async def slash_rolesub(interaction: discord.Interaction,
                        utilisateur: discord.Member, role: discord.Role):
    issuer = interaction.user if isinstance(interaction.user, discord.Member) else None
    if not issuer or not is_superior(issuer):
        await interaction.response.send_message(embed=discord.Embed(
            title="🚫 Accès refusé",
            description="Seul le supérieur peut utiliser cette commande.",
            color=COLOR_RED,
        ), ephemeral=True)
        return

    await log_command(interaction, utilisateur=str(utilisateur), role=str(role))
    try:
        await utilisateur.remove_roles(role, reason=f"/rolesub par {interaction.user}")
    except (discord.Forbidden, discord.HTTPException) as e:
        await interaction.response.send_message(embed=discord.Embed(
            description=f"❌ Impossible de retirer le rôle : `{e}`", color=COLOR_RED,
        ), ephemeral=True)
        return

    erl = _log_embed("➖ Rôle retiré", COLOR_RED, utilisateur)
    erl.add_field(name="Membre", value=f"{utilisateur.mention} — `@{utilisateur.name}`", inline=True)
    erl.add_field(name="Rôle", value=role.mention, inline=True)
    erl.add_field(name="Retiré par", value=f"{interaction.user.mention} — `@{interaction.user.name}`", inline=True)
    await send_log(interaction.guild, erl)

    await interaction.response.send_message(embed=discord.Embed(
        title="✅ Rôle retiré",
        description=f"{role.mention} a été retiré de {utilisateur.mention}.",
        color=COLOR_RED, timestamp=discord.utils.utcnow(),
    ))
    await asyncio.sleep(AUTO_DELETE_DELAY)
    try:
        msg = await interaction.original_response()
        await msg.delete()
    except (discord.NotFound, discord.HTTPException):
        pass


# ─── Run ─────────────────────────────────────────────────────────────────────
client.run(os.environ["TOKEN"])
